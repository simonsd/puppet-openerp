
// Auto generated file. Please don't modify.
openobject.gettext.update(
{"Do you really want to delete record ?": "Do you really want to delete record ?", "Do you really want to delete selected record(s) ?": "Do you really want to delete selected record(s) ?", "You selected to open %(tabs)s tabs - do you want to continue?": "You selected to open %(tabs)s tabs - do you want to continue?", "Do you really want to delete this record?": "Do you really want to delete this record?", "Object": "Object", "Field": "Field", "Invalid form, correct red fields.": "Invalid form, correct red fields.", "Do you really wants to create an inherited view here?": "Do you really wants to create an inherited view here?", "Do you really want to delete the attachment": "Do you really want to delete the attachment", "Do you really want to remove this node?": "Do you really want to remove this node?", "You must select at least one record.": "You must select at least one record."}
);

