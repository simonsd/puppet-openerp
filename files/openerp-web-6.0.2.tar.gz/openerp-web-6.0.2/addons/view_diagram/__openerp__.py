{
    "name" : "Diagram View for OpenERP",
    "version" : "1.0",
    "depends" : ["openerp"],
    "author" : "OpenERP SA",
    "description": """Diagram view for OpenERP.
    """,
    "website": 'http://www.openerp.com/',
    "active": True,
}

