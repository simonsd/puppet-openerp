{
    "name" : "CK editor widget for OpenERP",
    "version" : "3.2",
    "depends" : ["openerp"],
    "author" : "OpenERP SA",
    "description": """CK editor widget for OpenERP.""",
    'website': 'http://www.openerp.com/',
    'active': True,
}
