#!/usr/bin/env python

import sys
from openobject.admin import main

if __name__ == "__main__":
    try:
        main()
    except:
        sys.exit(1)

# vim: ts=4 sts=4 sw=4 si et

