{
    "name" : "Calendar View for OpenERP",
    "version" : "1.0",
    "depends" : ["openerp"],
    "author" : "OpenERP SA",
    "description": """Calendar view for OpenERP.
    """,
    "website": 'http://www.openerp.com/',
    "active": True,
}

